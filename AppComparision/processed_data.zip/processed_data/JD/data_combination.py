import pandas as pd
import json
import re

# 读取 JSON 文件
file_path1 = '/platform_comparision/JD/extracted_data/JD_cream.json'  # 替换为你的 JSON 文件路径
with open(file_path1, 'r', encoding='utf-8') as f:
    data1 = json.load(f)

file_path2 = '/platform_comparision/JD/extracted_data/JD_cream2.json'  # 替换为你的 JSON 文件路径
with open(file_path2, 'r', encoding='utf-8') as f:
    data2 = json.load(f)
#%%
df1_raw = pd.json_normalize(data1)
df2_raw = pd.json_normalize(data2)


#%%
result = pd.concat([df1_raw, df2_raw], ignore_index=True)

print(result)

#%%
result.to_csv('/Users/mac/python_projects/src/platform_comparision/JD/cleaned_data/mask.csv')

